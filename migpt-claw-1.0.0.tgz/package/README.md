# migpt-claw

小米小爱音箱 OpenClaw Channel 插件，让小爱音箱成为你的 🦞龙虾 语音助手。

## 功能特性

- 🎤 **语音对话** - 对小爱音箱说话，🦞 语音回复
- 📦 **流式输出** - 长文本分块播放，降低延迟
- 🎯 **智能分流** - 长内容/代码/多媒体自动引导至其他渠道
- 🔔 **状态提示** - 支持启动播报和收到消息提示音

## 快速开始

### 1. 安装插件

```bash
# 本地安装
openclaw plugins install ./migpt-claw-1.0.0.tgz
```

### 2. 配置账号

编辑 `~/.openclaw/openclaw.json` 配置文件：

**推荐配置（密码 + passToken）**：

```json
{
  "channels": {
    "migpt": {
      "enabled": true,
      "userId": "123456789",
      "password": "your_password",
      "passToken": "your_pass_token",
      "devices": ["客厅音箱"],
      "announceOnStart": true,
      "startupMessage": "您的小龙虾已上线，随时为您服务",
      "acknowledgeOnReceive": true,
      "receiveMessage": "收到，处理中"
    }
  }
}
```

**配置说明**：
- `userId`：小米 ID（数字，在小米账号「个人信息」-「小米 ID」查看）
- `password`：小米账号密码
- `passToken`：登录辅助凭证，配合密码一起使用，可降低触发验证码的概率（推荐配置，但不能替代密码）
- `devices`：小爱音箱设备名称列表
- `announceOnStart`：启动时是否播报上线文案
- `startupMessage`：上线播报文案
- `acknowledgeOnReceive`：收到消息时是否回复提示
- `receiveMessage`：收到消息回复文案
- `speakerControl`：音箱控制方式（`mina` 或 `miot`，默认 `mina`）

### 音箱控制方式说明

**`speakerControl`**：指定与小爱音箱通信的控制方式

- **`mina`**（默认）：使用 MiNA API，适用于大多数小爱音箱型号
- **`miot`**：使用 MIoT API，适用于部分需要特殊控制的型号

**已知需要 `miot` 的型号**：
- LX04（小爱音箱 Pro）
- X10A（小爱音箱 X10）
- L05B / L05C（小爱音箱 Play 增强版）

**注意**：
- 不同型号的小爱音箱对 `mina` 和 `miot` 的支持情况可能不同
- 如果默认 `mina` 方式无法正常工作，请尝试切换为 `miot`
- 完整兼容性列表参考：[MiGPT 兼容性文档](https://github.com/idootop/mi-gpt/blob/main/docs/compatibility.md)
- 建议自行编译测试以确定您的设备最佳配置

**特别说明**：当前项目未对所有小爱音箱型号进行全面测试，以上型号支持情况仅供参考。由于小爱音箱型号众多，不同型号可能存在差异，建议用户根据自身设备型号自行编译测试。

**配置示例**：

```json
{
  "channels": {
    "migpt": {
      "userId": "123456789",
      "password": "your_password",
      "passToken": "your_pass_token",
      "devices": ["客厅音箱"],
      "speakerControl": "miot"
    }
  }
}
```

### 3. 启动服务

```bash
openclaw gateway restart
```


## 设备名称

设备名称必须与米家 App 中设置的名称**完全一致**（包括大小写和空格）。

如果不确定设备名称，可以：
1. 开启 `debug: true` 配置
2. 启动服务查看设备列表
3. 日志中会打印所有可用设备

## 使用技能

### 播报规范

插件内置智能播报规范，AI 会自动判断内容是否适合语音播报：

- ✅ **适合播报**：简短回复、确认信息、简单问答
- ❌ **不适合播报**：代码、长文、数据、多媒体内容

对于不适合播报的内容，AI 会告知用户已通过其他渠道（如微信、邮件等）发送。

## 故障排查

### 登录失败

**错误**: `❌ 本次登录需要验证码，请检查 passToken 是否正确`

**解决**: passToken 作为辅助 Cookie 可降低验证码触发概率，但**不能替代密码**。请同时配置 `password` 和 `passToken`，缺少密码时 session 失效后将无法自动重新登录

### 设备未找到

**错误**: `❌ 找不到设备：客厅音箱`

**解决**:
1. 检查设备名称是否与米家 App 中完全一致
2. 开启 `debug: true` 查看可用设备列表
3. 注意错别字，如「音响」vs「音箱」

### 消息轮询失败

**错误**: `❌ getConversations failed`

**解决**:
1. 检查网络连接
2. 检查 serviceToken 是否过期
3. 删除 `.mi.json` 缓存文件重新登录

## 项目结构

```
migpt-claw/
├── index.ts                           # 插件入口
│
├── src/                               # 核心代码
│   ├── channel.ts                    # OpenClaw Channel 实现
│   ├── service.ts                    # MiService 服务层
│   ├── speaker.ts                    # MiSpeaker TTS 播放
│   ├── message.ts                    # 消息轮询和去重
│   ├── config.ts                     # 配置解析
│   ├── types.ts                      # TypeScript 类型定义
│   ├── outbound.ts                   # 消息发送接口
│   ├── onboarding.ts                 # 插件安装向导
│   ├── runtime.ts                    # 运行时管理
│   ├── mi/                           # 小米服务协议层
│   │   ├── mina.ts                  # MiNA 协议实现
│   │   ├── miot.ts                  # MIoT 协议实现
│   │   ├── account.ts               # 账号认证
│   │   ├── common.ts                # 通用工具
│   │   ├── index.ts                 # 模块导出
│   │   └── typing.ts                # 类型定义
│   └── utils/                        # 工具函数
│       ├── http.ts                  # HTTP 请求
│       ├── codec.ts                 # 编解码
│       ├── hash.ts                  # 加密哈希
│       ├── io.ts                    # 文件 IO
│       ├── debug.ts                 # 调试工具
│       ├── parse.ts                 # 解析工具
│       └── index.ts                 # 模块导出
│
├── skills/                            # OpenClaw Skills
│   ├── migpt-speaker-control/        # 小爱音箱全能控制
│   │   ├── index.ts                 # 12 个工具实现
│   │   └── SKILL.md                 # 完整使用文档
│   └── migpt-smart-home/             # 小米智能家居控制
│       ├── index.ts                 # 8 个工具实现
│       └── SKILL.md                 # 完整使用文档
│
├── debug/                             # 本地调试系统
│   ├── env.ts                        # 环境变量管理
│   ├── local.ts                      # 本地调试工具类
│   ├── test-full.ts                  # 完整诊断脚本
│   ├── test-speaker.ts               # 音箱功能测试
│   ├── test-smart-home.ts            # 智能家居测试
│   ├── GUIDE.md                      # 详细调试指南
│   └── QUICK_REF.md                  # 快速参考卡
│
├── .env.local.example                 # 环境变量模板
├── .gitignore                         # Git 忽略配置
├── openclaw.plugin.json               # 插件配置文件
├── package.json                       # NPM 配置
├── tsconfig.json                      # TypeScript 配置
├── tsup.config.ts                     # Tsup 构建配置
└── README.md                          # 项目说明
```

## 文件说明

### 核心模块

| 目录 | 说明 |
|------|------|
| `src/` | 插件核心代码，包括 Channel、Service、Message 等 |
| `src/mi/` | 小米服务协议层，MiNA 和 MIoT 实现 |
| `src/utils/` | 工具函数库 |
| `skills/` | OpenClaw Skills，提供龙虾可调用的工具 |

### 调试系统

| 文件 | 说明 |
|------|------|
| `debug/env.ts` | 从环境变量读取配置 |
| `debug/local.ts` | 本地调试工具和日志系统 |
| `debug/test-*.ts` | 预定义测试脚本 |
| `debug/GUIDE.md` | 详细调试指南 |
| `debug/QUICK_REF.md` | 快速参考 |
| `.env.local.example` | 环境变量模板 |

### 配置文件

| 文件 | 说明 |
|------|------|
| `openclaw.plugin.json` | OpenClaw 插件配置 |
| `package.json` | NPM 配置和脚本 |
| `tsconfig.json` | TypeScript 编译配置 |
| `tsup.config.ts` | 代码打包配置 |
| `.gitignore` | Git 忽略规则 |

## 开发和调试

### 安装依赖

```bash
npm install
```

### 开发流程

```bash
# 监听代码变化，自动编译
npm run dev

# 在另一个终端中运行测试
npm run debug:full
```

### 本地调试

本项目提供了完整的本地调试系统，可以在不依赖龙虾的情况下直接测试底层功能。

#### 快速开始

1. **配置环境变量**
   ```bash
   cp envConfig/.env.local.example envConfig/.env.local
   # 编辑 envConfig/.env.local，填入你的小米账号信息
   ```

2. **运行调试脚本**
   ```bash
   # 完整诊断
   npm run debug:full

   # 仅测试音箱功能
   npm run debug:speaker

   # 仅测试智能家居设备
   npm run debug:smart
   ```

3. **查看详细文档**
   ```bash
   # 详细调试指南
   cat debug/GUIDE.md

   # 快速参考
   cat debug/QUICK_REF.md
   ```

#### 调试系统特性

- ✅ 环境变量管理（敏感信息从 `.env.local` 读取）
- ✅ 彩色日志系统（success/error/warning/info）
- ✅ 多个预定义测试脚本
- ✅ 性能基准测试
- ✅ 自动诊断报告

#### 编写自定义测试

```typescript
// debug/test-my.ts
import { createDebugContext, logger } from './local.js';

async function main() {
  const ctx = await createDebugContext();
  if (!ctx) return;
  
  if (!(await ctx.init())) return;
  
  // 你的测试
  await ctx.testTts('Hello');
  logger.success('Done!');
}

main().catch(logger.error);
```

运行：
```bash
npx ts-node debug/test-my.ts
```

### 构建

```bash
# 编译 TypeScript 并生成打包文件
npm run build

# 生成的文件在 dist/ 目录
```

### NPM 命令参考

| 命令 | 说明 |
|------|------|
| `npm run dev` | 开发模式（监听代码变化） |
| `npm run build` | 构建项目 |
| `npm run debug:full` | 完整诊断 |
| `npm run debug:speaker` | 音箱功能测试 |
| `npm run debug:smart` | 智能家居测试 |

## AI 辅助开发

本项目由 **Qwen Code** + **Qwen3.5-Plus** 大模型开发实现。

- **[Qwen Code](https://qwenlm.github.io/qwen-code-docs/zh/users/overview/)** - 阿里巴巴通义实验室推出的终端 AI 编程助手（CLI 工具）
- **[Qwen3.5-Plus](https://github.com/QwenLM/Qwen)** - 通义千问 3.5 增强版大模型，提供强大的代码理解和生成能力

感谢 AI 助手在代码编写、问题排查和文档撰写过程中提供的智能辅助！🤖

## 相关项目

本项目受到以下优秀项目的启发和帮助：

- **[MiGPT Next](https://github.com/idootop/migpt-next)** - 让小爱音箱接入 AI 大模型，实现智能对话
- **[MiService](https://github.com/yihong0618/MiService)** - 小米账号认证和米家设备控制基础库

向以上项目的作者致敬！🙏

## 开源协议

MIT License

Copyright (c) 2024

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## 免责声明

本项目仅供学习和研究使用，不得用于任何商业用途或非法目的。

- 使用本项目时，请遵守当地法律法规和小米公司的相关服务条款
- 本项目与小米公司无任何关联，不构成任何官方支持或背书
- 使用本项目可能导致小米账号异常，请谨慎使用并自行承担风险
- 建议仅使用测试账号或非主要账号进行体验
- 如因使用本项目造成的任何损失（包括但不限于账号封禁、数据丢失等），本项目作者不承担任何责任
- 本项目按「原样」提供，不提供任何明示或暗示的保证

如将本项目用于生产环境或其他重要场景，请务必：
1. 仔细阅读并遵守小米开放平台的相关规范
2. 通过官方渠道获取合法的 API 调用权限
3. 评估潜在的法律和技术风险
